package com.functionalinterface;

@FunctionalInterface
public interface MyFirstFunctionalInterface {
	
	public void greet();
	
	//public void say();

}
