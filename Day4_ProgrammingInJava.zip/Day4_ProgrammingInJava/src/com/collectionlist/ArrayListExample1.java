package com.collectionlist;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class ArrayListExample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       List<String> fruits=new ArrayList<>();
       
       //Add the elements in list
       fruits.add("Apple");
       fruits.add("Banana");
       fruits.add("Mango");
       fruits.add("Orange");
       fruits.add("Orange");
       
       System.out.println("Fruits: "+ fruits);
       
       //Access by index
       System.out.println("First Fruit:"+ fruits.get(0));
       
       //update
       fruits.set(2, "kiwi");
       System.out.println("Fruits: "+ fruits);
       
       //remove
       fruits.remove(4);
       System.out.println("Fruits: "+ fruits);
       
       System.out.println("Index oF Banana:"+ fruits.indexOf("Banana"));
       System.out.println("Contains Apple?"+ fruits.contains("Apple"));
	
	    //iteration using For Each Loop
       for(String fruit: fruits) {
    	   System.out.println(fruit);
       }
       
      String[] fruitArray= fruits.toArray(new String[0]);
      System.out.println("Array:" + Arrays.toString(fruitArray));
      
      //Iteration using Iterator()
      Iterator<String> itr=fruits.iterator();
      while(itr.hasNext()) {
    	  String fruit=itr.next();
    	  System.out.println(fruit);
    			  
      }
      
      
      
      
      
      
      
      
      
      
       
       
	}

}
