package com.collectionmap;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class TreeMapExample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Integer, String>empMap=new TreeMap<>();
		empMap.put(101, "Jack");
		empMap.put(106,null);
		empMap.put(102, "Harry");
		empMap.put(103, "Smith");
		
		empMap.put(105, "Jack");
		empMap.put(105, "Ankit");
		empMap.put(104, "Janes");
		//empMap.put(null, null);
	    
		System.out.println(empMap);
	
	}

}
