package com.collectionmap;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class HashMapExample1 {
	public static void main(String[] args) {
		System.out.println("HashMap Example");
		//Map<Integer, String>empMap=new HashMap<>();
		Map<Integer, String>empMap=new LinkedHashMap<>();
		empMap.put(101, "Jack");
		empMap.put(102, "Harry");
		empMap.put(103, "Smith");
		empMap.put(104, "Janes");
		empMap.put(105, "Jack");
		empMap.put(105, "Ankit");
		empMap.put(null, null);
	
		System.out.println(empMap);
		
		//accessing values
		System.out.println("Employee 102:"+ empMap.get(102));
		
		System.out.println("Contains Key 103?"+ empMap.containsKey(103));
		System.out.println("Contains Value Ankit?"+ empMap.containsValue("Ankit"));
		
		Set <Integer> keys=empMap.keySet();
		Iterator <Integer >itr=keys.iterator();
		while(itr.hasNext()) {
			Integer key=itr.next();
			String value=empMap.get(key);
			
			System.out.println("Key is "+ key +" and value is : "+ value);
		}
		
		System.out.println();
	
	
	}
}
