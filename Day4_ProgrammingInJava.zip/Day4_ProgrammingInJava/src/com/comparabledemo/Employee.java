package com.comparabledemo;



public class Employee  implements Comparable<Employee>{
	private int employeeId;
	private String employeeName;
	private int yearsOfExperience;
	private double salary;
	public Employee(int employeeId, String employeeName, int yearsOfExperience, double salary) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.yearsOfExperience = yearsOfExperience;
		this.salary = salary;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public int getYearsOfExperience() {
		return yearsOfExperience;
	}
	public void setYearsOfExperience(int yearsOfExperience) {
		this.yearsOfExperience = yearsOfExperience;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public int compareTo(Employee emp) {
		// TODO Auto-generated method stub
		if (this.employeeId> emp.employeeId)
			return 1;
		else if(this.employeeId<emp.employeeId)
			return -1;
		else 
			return 0;
		
	}
	
	
}
