package com.comparabledemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ComparableTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee emp1 = new Employee(1001, "Employee1", 5, 60000);
		Employee emp2 = new Employee(1011, "Employee2", 8, 100000);
		Employee emp3 = new Employee(1006, "Employee3", 7, 80000);
		Employee emp4 = new Employee(1201, "Employee4", 3, 40000);
		List<Employee> empList = new ArrayList<>();
		empList.add(emp1);
		empList.add(emp2);
		empList.add(emp3);
		empList.add(emp4);
		Collections.sort(empList);
		EmployeeService  service=new EmployeeService();
		service.printEmployeeDetails(empList);
		
		/*emp1.compareTo(emp2)-->compare 1001 and 1011-->+1
		 * emp1.compareTo(emp3)
		 * emp1.compareTo(emp4)
		 * emp3(1006) and emp2(1011)1006<1011 return -1->swap
		 * 1001, 1006, 1011,1202
		 * compare index 1 and 0
		 * 1006>1001 ->+1 -->no swap
		 * compare index 3 and index2
		 * 1201>1011--+1 ==>no swap
		 * 
		 * 1001  1006 1011 1201
		 * 
		 * 
		 */
	}

}
