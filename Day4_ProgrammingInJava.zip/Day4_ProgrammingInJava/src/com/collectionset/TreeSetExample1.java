package com.collectionset;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class TreeSetExample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Set<String> userIds=new TreeSet<String>();
		Set<String> userIds=new TreeSet<String>(Collections.reverseOrder());
		  //userIds.add(1234);
		  userIds.add("John1989");
		  userIds.add("Riya1989");
		  userIds.add("Riya1989");
		  userIds.add("Harry1989");
		  userIds.add("Smith1989");
		//  userIds.add(null);
		  System.out.println(userIds);
		  System.out.println(userIds.size());
		  
		  
	}

}
