package com.java8.defaultstaticmethods;
interface MyInterface{
	public default void newMethod() {
		System.out.println("Implementated Method in interface:: newMethod()");
	}
	//public void sayHello();
}
public class Example1 implements MyInterface {

	public  void newMethod() {
		System.out.println("Implementated Method in class:: newMethod()");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Example1 obj=new Example1();
      obj.newMethod();
	}

}
