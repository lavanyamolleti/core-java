package com.java8.defaultstaticmethods;
/*
 * 
 * Static methods are same as default methods except 
 * that we cannot override them in implementation classes.
 */

interface MyInterface2{
	default int sumDefault(int n1, int n2) {
		return n1+ n2;
	}
	static int sumStatic(int n1, int n2) {
		return n1+ n2;
	}
}
public class Example3 implements MyInterface2 {
	@Override
	public int sumDefault(int n1, int n2) {
		return n1+ n2;
	}
/*
	@Override
	static int sumStatic(int n1, int n2) {
		return n1+ n2;
	}
	*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Example3 obj=new Example3();
		System.out.println(obj.sumDefault(3,4 ));
		
		System.out.println(MyInterface2.sumStatic(3, 6));
		
		
	}

}
