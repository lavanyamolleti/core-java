package com.java8.defaultstaticmethods;
/*
 * Class is implementing two interfaces with same default methods
 */

interface Vehicle{
	default void print() {
		System.out.println("I am Vehicle");
	}
}

interface FourWheeler{
	default void print() {
		System.out.println("I am FourWheeler");
	}
}

public class Example2 implements Vehicle,FourWheeler {
   /*
	@Override
	public void print() {
		// TODO Auto-generated method stub
		FourWheeler.super.print();
	}*/
	public void print() {
		System.out.println("I am Four Wheeler Vehicle");
	}

	public static void main(String[] args) {
		Example2 obj=new Example2();
		obj.print();
	}
}
