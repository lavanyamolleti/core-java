package com.java8.lambdaexpression;

interface SconcatInterface{
	public String Sconcat(String a, String b);
}
public class Example4LeWithMutltipleParameters {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SconcatInterface s=(a,b)->{
			return a+b;
		};
		System.out.println(s.Sconcat("Hello ", "Java "));
		
		SconcatInterface s1=(String a, String b)->a+b;
		System.out.println(s1.Sconcat("Hello ", "Lambda "));
	}

}
