package com.java8.lambdaexpression;

interface MyFunctionalInterface2{
	public String sayHello(String Name);
}
public class Example3LEWithOneParameter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyFunctionalInterface2 ref=n->{
			return "Hello "+ n;
		};
		System.out.println(ref.sayHello("Smith"));
		
		
		MyFunctionalInterface2 ref1=(String n)->{
			return "Hello "+ n;
		};
		System.out.println(ref.sayHello("Jack"));

	}

}
