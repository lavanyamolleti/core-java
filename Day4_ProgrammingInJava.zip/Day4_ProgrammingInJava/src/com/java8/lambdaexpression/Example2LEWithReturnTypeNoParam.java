package com.java8.lambdaexpression;

interface MyFunctionalInterface1{
	public String sayHello();
	
}
public class Example2LEWithReturnTypeNoParam {
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MyFunctionalInterface1 ref=()->"Hello Lambda";
		System.out.println(ref.sayHello());
		
		
		MyFunctionalInterface1 ref1=()->{ 
			return "Hello Lambda";
		};
		System.out.println(ref1.sayHello());
	}

}
