package com.java8.lambdaexpression;

interface MyFunctionalInterface{
	public void sayHello();
	
}
public class Example1LEWithNoParameter  {

	
	
	
	
	
	
	public static void main(String[] args) {
		//java 7 Anonymous classes
		MyFunctionalInterface obj=new MyFunctionalInterface() {
			
			@Override
			public void sayHello() {
				// TODO Auto-generated method stub
				System.out.println("Annonymous class");
			}
		};
		obj.sayHello();
		
		//Java 8
		MyFunctionalInterface Obj1=()->{System.out.println("Welcome to Lambda");};
		Obj1.sayHello();
		
	}

}
