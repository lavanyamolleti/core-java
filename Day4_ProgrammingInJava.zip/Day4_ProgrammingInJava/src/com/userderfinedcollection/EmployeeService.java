package com.userderfinedcollection;

import java.util.List;

public class EmployeeService {
	
	public void printEmployeeDetails(List<Employee> employeeList) {
		for(Employee employee: employeeList) {
			System.out.println("EmpiD is :"+ employee.getEmployeeId());
			System.out.println("Emp Name is :"+ employee.getEmployeeName());
			System.out.println("Emp years of experience is :"+ employee.getYearsOfExperience());
			System.out.println("Emp Salary  is :"+ employee.getSalary());
			System.out.println("**********************");
		}
	}

}
