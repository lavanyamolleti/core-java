package com.userderfinedcollection;

import java.util.ArrayList;
import java.util.List;

public class EmployeeTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Employee emp1=new Employee(1001,"Employee1", 3, 3000.00);
       Employee emp2=new Employee(1002,"Employee2", 6, 4000.00);
       Employee emp3=new Employee(1003,"Employee3", 7, 5000.00);
       Employee emp4=new Employee(1004,"Employee4", 8, 6000.00);
       List<Employee> empList=new ArrayList<>();
       empList.add(emp1);
       empList.add(emp2);
       empList.add(emp3);
       empList.add(emp4);
       EmployeeService service=new EmployeeService();
       service.printEmployeeDetails(empList);
	}

}
