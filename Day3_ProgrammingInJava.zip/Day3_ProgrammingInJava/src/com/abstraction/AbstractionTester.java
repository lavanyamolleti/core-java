package com.abstraction;

public class AbstractionTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    // BankAccount b1=new BankAccount();
		
		BankAccount hdfc=new HDFCBank("11111",3000.00,"Harry");
		BankAccount axis=new AxisBank("11123",7000.00,"Smith");
		
		hdfc.deposit(2000);
		hdfc.displayBalance();
		System.out.println("HdFC Interest: "+hdfc.calculateInterest());
		
		System.out.println("*******************");
		
		axis.deposit(4000);
		axis.displayBalance();
		System.out.println("Axis interest: "+axis.calculateInterest());
	}

}
