package com.abstraction;

public class HDFCBank extends BankAccount {

	
	public HDFCBank(String accountNumber, double balance, String accountHolder) {
		super(accountNumber,balance,accountHolder);
		
	}

	@Override
	public double calculateInterest() {
		// TODO Auto-generated method stub
		return balance * 0.04;
	}
	
}
