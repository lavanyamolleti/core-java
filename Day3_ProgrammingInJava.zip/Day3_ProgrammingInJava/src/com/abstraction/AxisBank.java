package com.abstraction;

public class AxisBank extends BankAccount {

	public AxisBank(String accountNumber, double balance, String accountHolder) {
		super(accountNumber,balance,accountHolder);
	}

	@Override
	public double calculateInterest() {
		// TODO Auto-generated method stub
		return balance* 0.035;
	}
	
	
}
