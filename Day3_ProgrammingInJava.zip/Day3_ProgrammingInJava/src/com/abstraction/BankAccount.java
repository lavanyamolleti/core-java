package com.abstraction;

public abstract class BankAccount {
	
	private String accountNumber;
	private  String accountHolder;
	 double balance;
	public BankAccount(String accountNumber, double balance, String accountHolder) {
		super();
		this.accountNumber = accountNumber;
		this.balance = balance;
		this.accountHolder=accountHolder;
	}
	
	public void displayBalance() {
		System.out.println("Account Holder: "+ accountHolder);
		System.err.println("Balance: "+ balance);
	}
	
	public void deposit(double amount) {
		balance +=amount;
		System.out.println(amount +" deposited.New balance is: "+ balance);
	}
	public abstract double calculateInterest();
	

}
