package com.finaldemo;

public class Parent {
	
	public final int count=0;
	
	public final void print() {
		//count++;
		System.out.println(count);
	}

}
