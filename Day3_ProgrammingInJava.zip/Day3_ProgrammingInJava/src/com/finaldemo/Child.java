package com.finaldemo;

public class Child extends Parent{
/*
	public void print() {
		//count++;
		System.out.println(count);
	}
	*
	*/
}
