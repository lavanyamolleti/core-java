package com.statickeyword;

public class Employee {

	public static int employeeCount;
	
	public Employee() {
		employeeCount++;
	}
	public  static int getEmployeeCount() {
		int a;
		return employeeCount;
	}
}
