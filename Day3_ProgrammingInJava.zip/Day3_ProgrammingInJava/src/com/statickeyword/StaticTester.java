package com.statickeyword;

public class StaticTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee emp1=new Employee();
		System.out.println("Employee Count: "+ emp1.getEmployeeCount());
		
		
		Employee emp2=new Employee();
		System.out.println("Employee Count: "+ emp2.getEmployeeCount());
		
		
		Employee emp3=new Employee();
		System.out.println("Employee Count: "+ emp3.getEmployeeCount());
		
		System.out.println("Employee Count: "+ emp1.employeeCount);
		System.out.println("Employee Count: "+ Employee.employeeCount);
		
		
		
		System.out.println("EmployeeCount:" + Employee.getEmployeeCount());

	}

}
