package com.statickeyword;

public class Bank {
	
	String name="HDFC Bank";
	
	static class ATM{
		static void showInfo() {
			System.out.println("ATM available 24*7");
		}
	}

}
