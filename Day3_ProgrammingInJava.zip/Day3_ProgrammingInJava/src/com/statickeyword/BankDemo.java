package com.statickeyword;

public class BankDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Bank.ATM.showInfo();
	}

}
