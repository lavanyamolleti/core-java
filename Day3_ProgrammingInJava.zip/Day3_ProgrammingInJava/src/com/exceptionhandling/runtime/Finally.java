package com.exceptionhandling.runtime;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Finally {
	public void division() {
		Scanner sc = new Scanner(System.in);
		try {
		System.out.println("enter nr and dr:");	
		byte nr=sc.nextByte();
		byte dr=sc.nextByte();
			
		System.out.println("Quotient="+ nr/dr);
		System.out.println("after exception");
		}
		
		catch(ArithmeticException | InputMismatchException e ) {
			System.out.println(e.getMessage());
		}
		
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		finally {
			System.out.println("Finally block executed");
			sc.close();
		}
		System.out.println("****End of division******** ");
		
	}
	public static void main(String[] args) {
		Finally obj=new Finally();
		obj.division();
	}
}
