package com.exceptionhandling.runtime;

import java.util.InputMismatchException;
import java.util.Scanner;

public class MultipleCatchJdk7 {
	
	public void division() {
		Scanner sc = new Scanner(System.in);
		try {
		System.out.println("enter nr and dr:");	
		byte nr=sc.nextByte();
		byte dr=sc.nextByte();
			
		System.out.println("Quotient="+ nr/dr);
		System.out.println("after exception");
		}
		
		catch(ArithmeticException | InputMismatchException e ) {
			System.out.println(e.getMessage());
		}
		
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		System.out.println("****End of division******** ");
		sc.close();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MultipleCatchJdk7 obj=new MultipleCatchJdk7();
		obj.division();
	}

}
