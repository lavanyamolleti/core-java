package com.exceptionhandling.runtime;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TryWithResources {
	
	public void division() {
		
		try(Scanner sc = new Scanner(System.in);) {
		System.out.println("enter nr and dr:");	
		byte nr=sc.nextByte();
		byte dr=sc.nextByte();
			
		System.out.println("Quotient="+ nr/dr);
		System.out.println("after exception");
		}
		
		catch(ArithmeticException | InputMismatchException e ) {
			System.out.println(e.getMessage());
		}
		
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		System.out.println("****End of division******** ");
		//sc.close();
	}
	public static void main(String[] args) {
		TryWithResources obj=new TryWithResources();
		obj.division();
		
		
	
	}
}
