package com.exceptionhandling.runtime;

import java.util.Scanner;

public class TryCatch {
	
	public void division(byte nr, byte dr) {
		try {
		System.out.println("Quotient="+ nr/dr);
		System.out.println("after exception");
		}
		catch(ArithmeticException e ) {
			System.out.println(e.getMessage());
		}
		System.out.println("****End of division******** ");
	}

	public static void main(String[] args) {
		TryCatch obj=new TryCatch();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Numerator");
		byte nr=sc.nextByte();
		
		System.out.println("Enter Denominator");
		byte dr=sc.nextByte();
		
		obj.division(nr, dr);
	}

}
