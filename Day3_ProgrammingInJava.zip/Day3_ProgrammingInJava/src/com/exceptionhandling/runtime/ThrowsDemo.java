package com.exceptionhandling.runtime;

public class ThrowsDemo {
	
	public static void validate (int age) {
		if(age>=18) {
			System.out.println("Eligible to drive!!");
		}
		else {
			throw new ArithmeticException("Not eligible to drive");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      validate(17);
	}

}
