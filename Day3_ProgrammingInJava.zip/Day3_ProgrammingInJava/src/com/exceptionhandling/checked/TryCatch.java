package com.exceptionhandling.checked;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class TryCatch {
	
	public static void read() {
		try {
					FileReader fr=new FileReader("src/files/welcome.txt");
							int ch;
							while((ch=fr.read())!=-1) {
					System.out.print((char) ch);
			
			} 
		}
		    catch (FileNotFoundException e) {
								// TODO Auto-generated catch block
				e.printStackTrace();
			}
			catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		read();
	}

}
