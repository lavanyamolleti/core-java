package com.exceptionhandling.checked;

public class CommonExceptionScenario {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      //String str=null;
      //System.out.println(str.length());
	
	 //int arr[]= {1,2,3};
	 //System.out.println(arr[5]);
		
		int num=Integer.parseInt("abc");
		System.out.println(num);
	
	
	}

}
