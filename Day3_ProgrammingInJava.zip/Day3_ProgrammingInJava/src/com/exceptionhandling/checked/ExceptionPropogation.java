package com.exceptionhandling.checked;

public class ExceptionPropogation {
static void method1() {
	int a=10/0;
	
}
static void method2() {
	method1();
}

static void method3() {
	method2();
}

public static void main(String[] args) {
	method3();
}
}
