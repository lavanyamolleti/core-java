package com.exceptionhandling.checked;

import java.io.IOException;

public class EPChecked {
	
	
	
	public static void x() throws IOException{
		throw new IOException("IO Exception");
	}
	
	public static void y() throws IOException {
		x();
	}
	public static void z() throws IOException {
		y();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			z();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
