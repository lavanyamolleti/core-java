package com.exceptionhandling.checked;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ThrowsDemo {
	
	
	
	public static void read() throws FileNotFoundException, IOException {
		try(FileReader fr=new FileReader("src/files/welcome.txt");) {
					
							int ch;
							while((ch=fr.read())!=-1) {
					System.out.print((char) ch);
			
			} 
		}
		    
	}

	public static void main(String[] args) throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub
		read();
	}

}
