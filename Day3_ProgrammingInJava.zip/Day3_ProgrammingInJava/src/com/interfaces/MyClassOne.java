package com.interfaces;

public class MyClassOne implements  MyInterface1{

	@Override
	public void display(String str) {
		// TODO Auto-generated method stub
		System.out.println("MyClass one :: display()");
	}
	
	public void myClassOneMethod() {
		System.out.println("myClassOneMethod()");
	}

}
