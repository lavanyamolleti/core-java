package com.interfaces;

public interface MyInterface3 extends MyInterface1, MyInterface2{

	public static final int a=4;
	public void someMethod();
}
