package com.interfaces;

public interface MyInterface1 {
	
	public abstract void display(String str);

	
}
