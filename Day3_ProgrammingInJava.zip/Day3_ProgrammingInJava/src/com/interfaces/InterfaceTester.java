package com.interfaces;

public class InterfaceTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
		MyClassOne obj=new MyClassOne();
		obj.display("Smith");
		obj.myClassOneMethod();
		
		MyInterface1 obj1=new MyClassOne();
		obj1.display("jack");
		*
		*/
		/*
		MyClassTwo obj2=new MyClassTwo();
		obj2.display("Harry");
		obj2.myMethod();
		obj2.greet();
		
		MyInterface1 ref=new MyClassTwo();
		ref.display("harry");
		
		MyInterface2 ref2=new MyClassTwo();
		ref2.myMethod();*
		/
		 * 
		 * 
		 */
		
		MyClassThree obj1=new MyClassThree();
		obj1.display("Harry");
		obj1.myMethod();
		obj1.someMethod();
		obj1.greet();
		
		MyInterface3 obj=new MyClassThree();
		obj.display("smith");
		obj.myMethod();
		obj.someMethod();
		//obj.greet();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
