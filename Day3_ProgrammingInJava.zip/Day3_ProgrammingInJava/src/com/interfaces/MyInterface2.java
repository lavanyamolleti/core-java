package com.interfaces;

public interface MyInterface2 {
	
	public void myMethod();
	


}
