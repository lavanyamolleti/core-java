package com.interfaces;

public class MyClassTwo implements MyInterface1, MyInterface2{

	@Override
	public void myMethod() {
		// TODO Auto-generated method stub
		System.out.println("MyClassTwo::myMethod");
	}

	@Override
	public void display(String str) {
		// TODO Auto-generated method stub
		System.out.println("MyClassTwo::display");
	}
	
	public void greet() {
		System.out.println("Greet()");
	}

	

}
