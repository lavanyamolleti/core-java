package com.interfaces;

public class MyClassThree implements MyInterface3{

	@Override
	public void display(String str) {
		// TODO Auto-generated method stub
		System.out.println("MyClassThree::display");
	}

	@Override
	public void myMethod() {
		// TODO Auto-generated method stub
		System.out.println("MyClassThree::myMethod");
	}

	@Override
	public void someMethod() {
		// TODO Auto-generated method stub
		System.out.println("MyClassThree::someMethod");
	}
	
	public void greet() {
		System.out.println("MyClassThree::greet");
	}

}
