package com.exceptiohandling.custom;

public class EmployeeDatabase {
	
	private static String[] employeeIds= {"A100","A102","A103"};
	
	public void findByEmployeeId(String empId) throws EmployeeDoesNotExistsException {
		boolean found=false;
		for(String id: employeeIds) {
			if(id.equals(empId)) {
				found=true;
			break;
		}
	}
	
	if(!found) {
		throw new EmployeeDoesNotExistsException("Employee with id "+ empId+ " does not exist");
	}
	
	System.out.println("Employee with Id:"+ empId+ " found.");

}
	public static void main(String[] args) {
		EmployeeDatabase db=new EmployeeDatabase();
		try {
			db.findByEmployeeId("B100");
		} catch (EmployeeDoesNotExistsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
