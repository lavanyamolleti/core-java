package com.exceptiohandling.custom;

public class EmployeeDoesNotExistsException extends Exception{
 public EmployeeDoesNotExistsException(String exception) {
	 super(exception);
 }
}
