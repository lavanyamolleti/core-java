package com.datatypes;

public class DatatypesExample1 {
	 public static void main(String[] args) {
		 
		 //Primitive Datatypes
		 byte b=120;
		 short s=23;
		 int age=23;
		 long phone=2345667897L;
		 
		 float temp=36.3f;
		 double price=888.88;
		 
		 char grade='A';
		 boolean isJavaFun=true;
		 
		 //Reference Datatypes
		 String name="Smith";
		 
		 System.out.println("Name: "+ name );
		 System.out.println("Age: "+ age );
		 System.out.println("phone: "+ phone );
		 System.out.println("Temp: "+ temp );
		 System.out.println("Price:" + price);
		 System.out.println("Grade: "+ grade );
		 
		 
		 
		 
	 }
}
