package com.constructors;

public class EmployeeTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Employee emp1=new Employee();
    emp1.displayDetails();
    
    
    Employee emp2=new Employee(1001, "sam",400.00);
    emp2.displayDetails();
    
    Employee emp3=new Employee(1002, "Jack");
    emp3.displayDetails();
    
    Employee emp4=new Employee(1003,5000.00,"smith");
    emp4.displayDetails();
	}

}
