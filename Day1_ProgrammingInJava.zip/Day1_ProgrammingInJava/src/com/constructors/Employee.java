package com.constructors;

public class Employee {
int id;
String empName;
double salary;

public Employee() {
	System.out.println("No -arg constructor Invoked");
}

public Employee(int id, String empName, double salary) {
	System.out.println("Three Parametrized constructor invoked: int,String, double");
	this.id=id;
	this.empName=empName;
	this.salary=salary;
}

public Employee(int id, String empName) {
	System.out.println("Two Parametrized constructor invoked: int,String");
	this.id=id;
	this.empName=empName;
}

public Employee(int id, double salary, String empName) {
	System.out.println("Three Parametrized constructor invoked: int,Double,String");
	this.id=id;
	this.empName=empName;
	this.salary=salary;
}


void displayDetails() {
	System.out.println("ID: " + id + ", Name: " + empName + ", Salary: " + salary);
}


}
