package com.loopingcontrolstatement;

import java.util.Scanner;

public class DoWhileExample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	// className objectName=new className();	
      Scanner sc=new Scanner(System.in);
      int pin;
      int correctPin=3456;
      do {
    	  System.out.println("Enter 4 digit Pin:");
    	  pin=sc.nextInt();
    	  if(pin !=correctPin) {
    		  System.out.println("Incorrect Pin...Try Again");
    	  }
    	  
      }
      while(pin!=correctPin);
      System.out.println("Pin Accepted and Access Granted!!!!");
      sc.close();
	}

}
