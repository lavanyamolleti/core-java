package com.loopingcontrolstatement;

import java.util.Scanner;

public class WhileExample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		int correctPin=1234;
		int attempts	=0;
		int maxattempts=3;
		
		
		while(attempts<maxattempts) {
			System.out.println("Enter the pin");
			int pin=sc.nextInt();
			
			if(pin==correctPin) {
				System.out.println("Access Granted");
				break;
			}
			else {
				System.out.println("Incorrect Pin");
				attempts++;
			}
		}
		if(attempts==maxattempts) {
			System.out.println(" Account Locked...Too many incorrect attempts");
		}
	}

}
