package com.conditionalcontrolstatement;

public class IfElseIfExample3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     int score =43;
     
     if(score>=90) {
    	 System.out.println("Grade A");
     }
     else if(score >=75 && score <90) {
    	 System.out.println("Grade B");
     }
     else if(score>=50 &&score <75) {
    	 System.out.println("Grade C");
      }
     else {
    	 System.out.println("Fail");
     }
     System.out.println("****End of If Else If Ladder *********");
     
	}

}
