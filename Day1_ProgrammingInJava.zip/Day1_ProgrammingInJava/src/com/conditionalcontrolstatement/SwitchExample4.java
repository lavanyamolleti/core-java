package com.conditionalcontrolstatement;

public class SwitchExample4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   int day=8;
   switch(day) {
   default:
	   System.out.println("Entered wrong day number");
   break;	   
   case 1: System.out.println("Monday");
   break;
   case 2: System.out.println("Tuesday");
   break;
   case 3: System.out.println("Wednesday");
   break;
   case 4: System.out.println("Thursday");
   break;
   case 5: System.out.println("Friday");
   break;
   case 6: System.out.println("Saturday");
   break;
   case 7: System.out.println("Sunday");
   break;
  
	 
   }
   System.out.println("****Switch over");
	}

}
