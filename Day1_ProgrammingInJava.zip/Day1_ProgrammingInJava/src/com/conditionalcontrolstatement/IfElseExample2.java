package com.conditionalcontrolstatement;

public class IfElseExample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     int age=19;
     if(age>=18) {
    	 System.out.println("You are eligible to vote!!!");
     }
     else {
    	 System.out.println("You are not eligible to vote !!");
     }
     System.out.println("*******End of If Else Ladder ******");
	}

}
