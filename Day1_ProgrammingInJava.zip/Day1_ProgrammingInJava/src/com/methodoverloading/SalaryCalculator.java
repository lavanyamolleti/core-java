package com.methodoverloading;

public class SalaryCalculator {

	
	public double calculateSalary(double basic) {
		System.out.println("calculateSalary(double basic) ");
		return basic;
	}
	
	public double calculateSalary(double basic, double bonus) {
		return basic+ bonus;
	}
	
	public double calculateSalary(double basic, double bonus, double deductions) {
		return basic+ bonus-deductions;
	}
	public float calculateSalary(float basic) {
		System.out.println("calculateSalary(float basic) ");
		return basic;
	}
	
	public int calculateSalary(int salary) {
		System.out.println("calculateSalary(int salary) ");
		return salary;
	}
	public int calculateSalary(short salary) {
		System.out.println("calculateSalary(short salary) ");
		return salary;
	}
	
	
	public static void main(String[] args) {
		SalaryCalculator obj=new SalaryCalculator();
		Short s=400;
		System.out.println("Only Basic: "+obj.calculateSalary(s));
		System.out.println("Only Basic: "+obj.calculateSalary(30000.00));
		System.out.println("Only Basic: "+obj.calculateSalary(30000.00f));
		System.out.println("Basic + Bonus: "+obj.calculateSalary(30000, 12000));
		System.out.println("Basic + Bonus -Deductions: "+obj.calculateSalary(30000, 230000,4000));
	}
	
}
