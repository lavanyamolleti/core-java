package com.operators;

public class BitwiseOperatorExample5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
 *  &-->both bits are 1 then result is 1
 *  |-->If either bit is 1 result is 1
 *  !-> !true-->false  !false-->true
 *  ^--> Results in  1 if bits are different
 *       Results in  0 if bits are same
 */
		
boolean x=true;
boolean y=false;
boolean a=x|y;
boolean b=x&y;
boolean c=x^y;
boolean d=!x;

System.out.println("x|y ="+ a);
System.out.println("x&y ="+ b);
System.out.println("x^y ="+ c);
System.out.println("!x ="+ d);
		
	}

}
