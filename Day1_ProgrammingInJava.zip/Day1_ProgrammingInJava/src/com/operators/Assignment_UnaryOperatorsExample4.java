package com.operators;

public class Assignment_UnaryOperatorsExample4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   int num=10;
  System.out.println("Assignment Operators"); 
  num+=5; //num=num+5;
  System.out.println("Num is : "+ num);
  
  num-=5; //num=num-5;
  System.out.println("Num is : "+ num);
  
  num%=5; //num=num/5;
  System.out.println("Num is : "+ num);
  
  System.out.println("Unary Opeartors");
  // ++ ,--
  /*
   * ++i //Preincrement i=i+1
   * i++ //Post Increment i=i+1
     --i
     i--
   */
  int i=2;
  System.out.println("i= "+ i);
  System.out.println("i="+ ++i);//change and then use
  System.out.println("i="+ i++);//use and then change
  System.out.println("i= "+ i);
  
  int j=8;
  System.out.println("j= "+ j);
  System.out.println("j="+ --j);//change and then use
  System.out.println("j="+ j--);//use and then change
  System.out.println("j= "+ j);//6
  
  int assign=j--;
  System.out.println(assign);
  System.out.println(j);
		  
  
  
  
  
	}
}
