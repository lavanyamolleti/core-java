package com.operators;

public class RelationalOperatorExample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 int data1=123 , data2=321;
 /*
  * 123 == 321 is false
123 !=  321 is true
123 >  321 is false
123 <  321 is true
  */
 
System.out.println(data1 + " == "+  data2 + " is "+ (data1==data2)); 
System.out.println(data1 + " !="+  data2 + " is "+ (data1!=data2)); 
System.out.println(data1 + " > "+  data2 + " is "+ (data1>data2)); 
System.out.println(data1 + " < "+  data2 + " is "+ (data1<data2)); 

	}

}
