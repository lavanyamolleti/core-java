package com.operators;

public class ArithmeticOperatorsExample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int a=20, b=6;
    System.out.println("Arithmetic Operators: ");
    System.out.println("a+b ="+ (a+b));
    System.out.println("a-b ="+ (a-b));
    System.out.println("a*b ="+ (a*b));
    System.out.println("a/b ="+ (a/b));
    System.out.println("a%b ="+ (a%b));
   
	}

}
