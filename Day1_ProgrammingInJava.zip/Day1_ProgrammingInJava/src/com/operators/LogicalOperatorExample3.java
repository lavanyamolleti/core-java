package com.operators;

public class LogicalOperatorExample3 {
	/*
	 * false || true is true
false && true is false
! false is true
	 
	 *
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int data1=123, data2=321;
		
System.out.println((data1==data2) + " || "+ (data1!=data2)+ " is "+ ((data1==data2)||(data1!=data2)));
System.out.println((data1==data2) + " && "+ (data1!=data2)+ " is "+ ((data1==data2)&&(data1!=data2)));
System.out.println("! "+ (data1==data2) + " is "+ !(data1==data2));
	}

}
