package com.classandobject;

import java.util.Scanner;

public class EmployeeTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee emp1=new Employee();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter employeeName");
		String name=sc.next();
		System.out.println("Enter employeeId");
		int eid=sc.nextInt();
		System.out.println("Enter salary");
		float salary=sc.nextFloat();
		emp1.setEmpId(eid);
		emp1.setEmpName(name);
		emp1.setSalary(salary);
		
		System.out.println("Employee Details are:");
        System.out.println("EmployeeId : "+ emp1.getEmpId());	
        System.out.println("EmployeeName : "+ emp1.getEmpName());	
        System.out.println("EmployeeSalary : "+ emp1.getSalary());
        sc.close();
	}

}
