package com.classandobject;

public class ElectricityBill {
	
	private int unitConsumed;
	private double billAmount;
	public int getUnitConsumed() {
		return unitConsumed;
	}
	public void setUnitConsumed(int unitConsumed) {
		this.unitConsumed = unitConsumed;
	}
	public double getBillAmount() {
		return billAmount;
	}
	
	/*
	 * accessmodifier returntype methodName(paramters){
	 * 
	 * }
	 */
	public void calculateBillAmount() {
		if(unitConsumed<=50) {
			billAmount=unitConsumed*2;
			
		}
		if(unitConsumed<50 && unitConsumed<=100) {
			billAmount=unitConsumed*4;
		}
		else {
			billAmount=unitConsumed*6;
		}
	}
	
	
	

}
