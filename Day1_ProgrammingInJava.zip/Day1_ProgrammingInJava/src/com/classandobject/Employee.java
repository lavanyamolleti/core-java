package com.classandobject;

public class Employee {

	private int empId;
	private String empName;
	private float salary;
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	
	public void display() {
		int localVariable=5;
		System.out.println("empId: "+ empId);
		System.out.println("empName: "+ empName);
		System.out.println("Salary: "+ salary);
		System.out.println("Local Variable: "+ localVariable);
	}
	
	public void m1() {
		//System.out.println(localVariable);
	}
}
