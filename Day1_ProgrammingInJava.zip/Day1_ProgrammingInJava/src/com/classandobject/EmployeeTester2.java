package com.classandobject;

public class EmployeeTester2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     //Local and instance variable
		Employee emp1=new Employee();
		emp1.display();
	}

}
