package com.classandobject;

import java.util.Scanner;

public class ElectricityBillTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int unit;
       ElectricityBill bill=new ElectricityBill();
       Scanner sc=new Scanner(System.in);
       System.out.println("Enter unit Consumed:");
       unit=sc.nextInt();
       bill.setUnitConsumed(unit);
       bill.calculateBillAmount();
       System.out.println("Unit consumed: "+ bill.getUnitConsumed());
       System.out.println("Bill Amount :"+ bill.getBillAmount());
	}

}
