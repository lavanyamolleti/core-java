package com.accenture.lkm.test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.MethodMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.accenture.lkm.Employee;

/*
 * The @ExtendWith annotation is used in JUnit 5 to register extensions (also known as "test instance post-processors"). 
 * When you use @ExtendWith(SpringExtension.class), you're essentially telling JUnit to enable Spring support for the test 
 * class.
 */
@ExtendWith(SpringExtension.class)

/*
 * The @ContextConfiguration annotation in Spring test framework is used to specify the locations of the configuration files 
 * that define the application context for the test.
 * The Application context is loaded only once, and cached for all the test methods 
 */
@ContextConfiguration(locations = "/com/accenture/lkm/resources/my_springbean.xml")
public class TestEmployeeClass {

	@Autowired
	private Employee employee;
	@DirtiesContext(methodMode = MethodMode.BEFORE_METHOD)
	@Test
	public void testEmployee() {
		System.out.println("*** testEmployee ***");
		Assertions.assertNotNull(employee);
	}
	
	@Test
	public void testEmployeeAddress() {
		System.out.println("*** testEmployeeAddress ***");
		Assertions.assertNotNull(employee.getAddress());
	}

	
	/*
	 * In Spring Framework's testing support, the @DirtiesContext annotation is used to indicate that the ApplicationContext 
	 * associated with a test is dirty and should be recreated before running a specific test method. 
	 * When methodMode is set to BEFORE_METHOD, it indicates that the context should be marked as dirty and recreated before 
	 * the execution of the test method.
	 */

}

/*
methodMode
@DirtiesContext(methodMode = MethodMode.BEFORE_METHOD)
@DirtiesContext(methodMode = MethodMode.AFTER_METHOD)

classMode
@DirtiesContext(classMode = ClassMode.BEFORE_CLASS)
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)
*/