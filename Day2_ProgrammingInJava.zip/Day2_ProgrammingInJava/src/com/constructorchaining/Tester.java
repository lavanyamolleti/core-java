package com.constructorchaining;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Manager m1=new Manager("Smith", 2000.00, "lKM");
     m1.displayDetailsManager();
     System.out.println("*************");
     
     
     //Static Binding
     Manager m3=new Manager("Jack", 2000.00, "lKM");
     m3.displayDetails();
     m3.displayDetailsManager();
     System.out.println("***************");
     
     //Dynamic Binding
     //Parentclass ref=new ChidClass();
     Employee e=new Manager("Jack", 2000.00, "lKM");
     e.displayDetails();
     
     System.out.println("***************");
     Manager m2=new Manager("Jack", 2000.00, "lKM");
     m2.displayDetailsManager();
	}

}
