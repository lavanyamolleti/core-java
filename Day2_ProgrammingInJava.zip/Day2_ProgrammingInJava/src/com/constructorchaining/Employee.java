package com.constructorchaining;

public class Employee {

	private String name;
	private double salary;
	public Employee(String name, double salary) {
		super();
		this.name = name;
		this.salary = salary;
	}
	
	public void displayDetails() {
		System.out.println("Name: "+name);
		System.out.println("Salary: "+ salary);
	}
	
	
	
}
