package com.constructorchaining;

public class Manager extends Employee {

	private String department;

	public Manager(String name, double salary, String department) {
		super(name, salary);
		this.department = department;
	}
	
	public void displayDetailsManager() {
		super.displayDetails();
		System.out.println("Department: "+ department);
	}
	
	
	
	
}
