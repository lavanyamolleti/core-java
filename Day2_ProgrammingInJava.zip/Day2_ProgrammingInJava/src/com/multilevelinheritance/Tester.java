package com.multilevelinheritance;

public class Tester {
	public static void main(String[] args) {
		Maruti800 obj=new Maruti800();
		obj.vehicleType();
		obj.brand();
		obj.speed();
	}
}
