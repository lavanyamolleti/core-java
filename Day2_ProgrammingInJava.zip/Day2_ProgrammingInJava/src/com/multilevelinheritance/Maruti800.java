 package com.multilevelinheritance;

public class Maruti800 extends Maruti{

	public Maruti800() {
		super();
		System.out.println("Maruti800 Constructor");
	}
	public void speed() {
		System.out.println("Max:: 80 kmph");
	}
	
	public void display() {
		super.brand();
		super.vehicleType();
		System.out.println(super.carno);
	}
}
