package com.multilevelinheritance;

public class Car {
	
	public Car() {
		System.out.println("Inside Car class constructor");
	}
	
	public void vehicleType() {
		System.out.println("Vehicle Typs::: Car");
	}

}
