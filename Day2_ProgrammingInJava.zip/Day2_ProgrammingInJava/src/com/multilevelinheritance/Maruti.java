package com.multilevelinheritance;

public class Maruti extends Car{

	int carno;
	
	public Maruti() {
		super();
		System.out.println("Maruti class constructor");
	}
	public void brand() {
		System.out.println("Brand:: Maruti");
	}

}
