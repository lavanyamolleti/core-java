package com.strings;

public class StringExample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str1=new String("GFT");
		String str2=str1;
		System.out.println("Str1= "+ str1);
		System.out.println("Str2= "+ str2);
		System.out.println("== operator "+ (str1==str2));
		System.out.println("equals method "+ str1.equals(str2));
		String str3=new String("GFT");
		System.out.println("== operator "+ (str1==str3));
		System.out.println("equals method "+ str1.equals(str3));
		
		str1=str1.toLowerCase();
		System.out.println("Str1= "+ str1);
		System.out.println("Str2= "+ str2);
		System.out.println("== operator "+ (str1==str2));
		System.out.println("equals method "+ str1.equals(str2));
		System.out.println("equals method "+ str1.equalsIgnoreCase(str2));
		        //   0123456
		String str4="helloll";
		String str5="Java";
		System.out.println(str4.concat(str5));
		System.out.println(str4.length());
		
		System.out.println(str4.indexOf('l'));
		System.out.println(str4.indexOf("ll"));
		System.out.println(str4.lastIndexOf('l'));//6
		System.out.println(str4.lastIndexOf("ll"));//5
		str4=str4.replace('h','H');
		System.out.println(str4);
		
		/*
		 * boolean startsWith(String str): It returns true 
		 	* if the str is a prefix of the String.
boolean startsWith(String str, index fromIndex): It returns true 
if the String begins with str, it starts looking from the specified index �fromIndex�.
		 */
		System.out.println(str5.startsWith("Ja"));
		System.out.println(str5.startsWith("va",2));
		
		/*
		 * String substring(int beginIndex): Returns the substring 
		 * starting 
		 * from the specified index(beginIndex) till the end 
		 * of the string
		 * 
		 * String substring(int beginIndex, int endIndex): Returns 
		 * the substring starting from the 
		 * given index(beginIndex) till the specified 
		 * index(endIndex)-1
		 */
		//str5="Java"
		System.out.println(str5.substring(2));
		System.out.println(str5.substring(1, 3));
		
		String str6="Java Programming";
		System.out.println(str6.substring(0, 6));
		
		String string="004-67895-5677";
		String parts[]=string.split("-");
		System.out.println(parts[0]);
		System.out.println(parts[1]);
		System.out.println(parts[2]);
		
	}

}
