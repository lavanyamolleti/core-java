package com.arrayofobjects;

import java.util.Scanner;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  //int array[]=int[5];
		Employee[] employee=new Employee[3];
		
		Scanner sc=new Scanner(System.in);
		int empId;
		String empName;
		for(int i=0;i<employee.length;i++) {
			System.out.println("Enter Employeeid["+ i+ "]:");
			empId=sc.nextInt();
			System.out.println("Enter EmployeeName["+ i+ "]:");
			empName=sc.next();
			employee[i]=new Employee(empName, empId);
			
		}
		
		for(int i=0;i<employee.length;i++) {
			employee[i].display();
			System.out.println("*****");
		}
	}

}
