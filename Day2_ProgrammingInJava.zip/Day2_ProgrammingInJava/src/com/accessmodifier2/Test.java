package com.accessmodifier2;

import com.accessmodifier1.Parent;

public class Test {
	public static void main(String[] args) {
		Parent p=new Parent();
		System.out.println(p.pVar);
		//System.out.println(p.protectVar);
		//System.out.println(p.defVar);
		//System.out.println(p.priVar);
		
	}
}
