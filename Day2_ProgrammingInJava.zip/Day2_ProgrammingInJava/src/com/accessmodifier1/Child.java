package com.accessmodifier1;

public class Child extends Parent {
	
	public void accessFromChild() {
		System.out.println(pVar);
		System.out.println(protectVar);
		System.out.println(defVar);
		//System.out.println(priVar);
	}

}
