package com.accessmodifier1;

public class Parent {
	
	public String pVar="public Variable";
	protected String protectVar="protectedVariable";
	String defVar="DefaultVariable";
	private String priVar="privateVariable";
	
	public void showAccess() {
		System.out.println(pVar);
		System.out.println(protectVar);
		System.out.println(defVar);
		System.out.println(priVar);
	}

}
