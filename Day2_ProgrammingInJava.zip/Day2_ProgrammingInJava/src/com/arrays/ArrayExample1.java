package com.arrays;

import java.util.Scanner;

public class ArrayExample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      //Declare and create the array
		
	   int[] marks=new int[5];
	   
	   Scanner sc=new Scanner(System.in);
	   System.out.println("Enter the elements of array:");
	   for(int i=0;i<=4;i++) {
		   System.out.println("marks["+i+ "]:");
		   marks[i]=sc.nextInt();
	   }
	   System.out.println("Student Marks:");
	   for(int i=0;i<=4;i++) {
		  System.out.println("Student "+ (i+1)+ ": "+ marks[i]);
	   }
	   
	   //calculate sum and average
	   
	   /*
	    * for(datatype variablename: arrayname){
	    * 
	    * }
	    */
	   int sum=0;
	   for (int mark: marks) {
		   sum=sum+mark;
	   }
	   
	   
    double average=(double)sum/marks.length;	
    System.out.println("Total Marks:"+ sum);
    System.out.println("Average Marks: "+ average);
	   
	//Find minium and maximum marks 
    
    int max=marks[0];
    int min=marks[0];
    for (int mark: marks) {
    	if (mark>max)max=mark;
    	if(mark<min)min=mark;
    }
    System.out.println("Highest Mark:"+ max);
    System.out.println("Minimum marks: "+ min);
    
    
    
    
    
    
    
	   
	   
	   
	   
	   
	   
	   
	}

}
