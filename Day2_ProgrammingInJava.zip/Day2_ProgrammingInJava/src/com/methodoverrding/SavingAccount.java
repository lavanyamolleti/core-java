package com.methodoverrding;

public class SavingAccount extends BankAccount{

	@Override
	public void calculateInterest() {
		System.out.println("SavingAccount Interest is 5% yearly");
	}
	
	public void showBalance() {
		System.out.println("Saving Account Balance: "+ balance);
	}
	
	public void greet() {
		System.out.println("Svaing Account greet");
	}
}

