package com.methodoverrding;

public class BankAccount {
	
	double balance=1000000;
	protected void calculateInterest() {
		System.out.println("Generic Interest is 3% yearly");
	}
	
	public void showBalance() {
		System.out.println("Account Balance: "+ balance);
	}
	
	public void welcome() {
		System.out.println("Welcome to bank");
	}

}
