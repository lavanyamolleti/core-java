package com.methodoverrding;

public class CurrentAccount extends BankAccount{
	@Override
	public void calculateInterest() {
		System.out.println("Current Account has no interest");
	}
	
	public void showBalance() {
		System.out.println("Current Account Balance: "+ balance);
	}
}
