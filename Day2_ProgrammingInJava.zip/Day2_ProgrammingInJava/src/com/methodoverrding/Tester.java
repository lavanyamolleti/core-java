package com.methodoverrding;

public class Tester {
	public static void main(String[] args) {
		//Static binding
		SavingAccount acc1=new SavingAccount();
		acc1.calculateInterest();
		acc1.showBalance();
		acc1.welcome();
		acc1.greet();
		System.out.println("**************");
		//Dynamic Binding
		BankAccount acct2=new SavingAccount();
		acct2.welcome();
		acct2.calculateInterest();
		acct2.showBalance();
		//acct2.greet();
		System.out.println("**************");
		
		BankAccount acct3=new CurrentAccount();
		acct3.calculateInterest();
		acct3.showBalance();
		acct3.welcome();
		
		
		
		
		
	}
}
