package com.inheritance;

public class TeamLead extends Employee {
	private int noOfprojectsManaged;

	public int getNoOfprojectsManaged() {
		return noOfprojectsManaged;
	}

	public void setNoOfprojectsManaged(int noOfprojectsManaged) {
		this.noOfprojectsManaged = noOfprojectsManaged;
	}
	
	

}
