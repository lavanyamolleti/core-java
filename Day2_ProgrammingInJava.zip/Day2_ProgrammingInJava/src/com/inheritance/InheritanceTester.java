package com.inheritance;

public class InheritanceTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SoftwareEngineer s1=new SoftwareEngineer();
		s1.setEmployeeId(1001);
		s1.setEmployeeName("jack");
		s1.setProjectName("lkm");
		
		System.out.println("Software Engineer details: ");
		System.out.println("Name: " + s1.getEmployeeName());
		System.out.println("ID: " + s1.getEmployeeId());
		System.out.println("Project Name: " + s1.getProjectName());
		System.out.println("***************");
		
		TeamLead t1=new TeamLead();
		t1.setEmployeeId(1002);
		t1.setEmployeeName("Harry");
		t1.setNoOfprojectsManaged(3);
		System.out.println("Team Lead details: ");
		System.out.println("Name: " + t1.getEmployeeName());
		System.out.println("ID: " + t1.getEmployeeId());
		System.out.println("No of projects: " + t1.getNoOfprojectsManaged());

	}

}
