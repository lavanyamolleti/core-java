package com.classrelationship.composition;

import java.util.Scanner;

public class CompositionTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("Enter account no:");
int acc=sc.nextInt();
System.out.println("Enter amount:");
double amount=sc.nextDouble();

Customer cust1=new Customer(acc,amount);
cust1.setCustomerName("JacK");

System.out.println("Account Details are:");
System.out.println("Customer Name: "+ cust1.getCustomerName());
System.out.println("Account no:"+ cust1.getAccount().getAccountNo());
System.out.println("Amount:"+ cust1.getAccount().getAmount());

	}

}
