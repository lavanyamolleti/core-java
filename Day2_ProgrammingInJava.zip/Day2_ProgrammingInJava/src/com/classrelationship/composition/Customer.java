package com.classrelationship.composition;

public class Customer {
	private String customerName;
	private Account account;
	
	public Customer(int acctno, double amt) {
		account=new Account();
		account.setAccountNo(acctno);
		account.setAmount(amt);
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
	this.customerName = customerName;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}
	

}
