package com.classrelationship.aggregation;

public class AggregationTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Faculty faculty=new Faculty();
     faculty.setFacultyId(1001);
     faculty.setFacultyName("John");
     
     
     Department d1=new Department();
     d1.setDepartmentName("LKM");
     d1.setFaculty(faculty);
     
     System.out.println("Department Name: "+ d1.getDepartmentName());
     System.out.println("Faculty Id: "+ d1.getFaculty().getFacultyId());
     System.out.println("faculty Name: "+ d1.getFaculty().getFacultyName());
	}

}
