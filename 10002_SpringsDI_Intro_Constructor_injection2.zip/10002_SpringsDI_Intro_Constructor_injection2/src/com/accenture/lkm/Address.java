package com.accenture.lkm;

public class Address {

	private String addressLine1;
	private String addressLine2;

	public Address(String addressLine1, String addressLine2) {
		super();
		System.out.println("Address Class Parameterized Constructor....");
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public String getAddressLine2() {

		return addressLine2;
	}

}
